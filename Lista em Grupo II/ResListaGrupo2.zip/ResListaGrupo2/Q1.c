#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int contarVizinhosVivos(int mat[30][30], int l, int c)
{
	int linhaIni;
	int linhaFim;
	
	int colunaIni;
	int colunaFim;
	
	//Primeira linha
	if (l == 0)		linhaIni = l;
	else			linhaIni = l - 1;
	
	//Ultima linha
	if (l == 29)	linhaFim = l;
	else 			linhaFim = l + 1;	
	
	//Primeira coluna
	if (c == 0) 	colunaIni = c;
	else			colunaIni = c - 1;
	
	//Ultima coluna
	if (c == 29) 	colunaFim = c;
	else			colunaFim = c + 1;	
		
	int contaVivo = 0;
	for (int i = linhaIni; i <= linhaFim; i++)
	{
		for (int j = colunaIni; j <= colunaFim; j++)
		{
			if (mat[i][j] == 1)
				contaVivo++;
		}
	}
	//Descontar a pr�pria c�lula [l][c]
	contaVivo = contaVivo - mat[l][c];
	return contaVivo;	
}

void InicializarVazio(int mat[30][30])
{
	for (int i = 0; i < 30; i++)
		for (int j = 0; j < 30; j++)
			mat[i][j] = 0;
}

void InicializarAleatorio(int mat[30][30])
{
	srand(time(0));
	for (int i = 0; i < 30; i++)
		for (int j = 0; j < 30; j++)
			mat[i][j] = rand() % 2; //0 ou 1
}

void InicializarLeitura(int mat[30][30])
{
	int l, c;
	do
	{
		scanf("%d %d",&l,&c);
		if (l >= 0 && c >= 0)
			mat[l][c] = 1;		
	}
	while (l >= 0 && c >= 0);
}

void ImprimirMatriz(int mat[30][30])
{
	system("cls");
	for (int i = 0; i < 30; i++)
	{
		for (int j = 0; j < 30; j++)
		{
			if (mat[i][j] == 0)
				printf(" ");
			else
				printf("O");
		}
		printf("\n");
	}
	sleep(1);  
}

void AplicarRegra(int mat[30][30])
{
	int aux[30][30];
	for (int i = 0; i < 30; i++)
		for (int j = 0; j < 30; j++)
			aux[i][j] = mat[i][j];
	
	for (int i = 0; i < 30; i++)
	{	
		for (int j = 0; j < 30; j++)
		{		
			//A contagem � feita na matriz anterior, sem altera��es.
			int vizinhosVivos = contarVizinhosVivos(aux,i,j);
			switch (vizinhosVivos)
			{
				case 0 : mat[i][j] = 0; break; //Morre de solid�o -> Sempre ser� 0
				case 1 : mat[i][j] = 0; break; //Morre de solid�o -> Sempre ser� 0
				case 2 : mat[i][j] = aux[i][j]; break; //Dois vizinhos permanece como est�
				case 3 : mat[i][j] = 1; break; //Se tem 3 vizinhos, fica vivo (nasce ou permanece)
				default: mat[i][j] = 0; //4 ou mais, morre de superpopula��o -> Sempre ser� 0
			}
		}
	}
}

void TesteGlider(int mat[30][30])
{
	mat[3][4] = 1;
	mat[4][6] = 1;
	mat[5][4] = 1;
	mat[5][5] = 1;
	mat[5][6] = 1;
}

int main()
{
	int mat[30][30];
	InicializarVazio(mat);
	
	int op;
	do
	{
		printf("Digite o modo de Inicializa��o: \n 1 - Randomico\n 2 - Digitar Posi��es\n 3 - Teste Glider\n");
		scanf("%d",&op);
		
		if (op != 1 && op != 2 && op != 3)
			printf("Op��o Inv�lida. \t Tente novamente.\n");
			
	}
	while (op != 1 && op != 2 && op != 3);
	
	switch (op)
	{
			case 1: InicializarAleatorio(mat); break;
			case 2: InicializarLeitura(mat); break;
			case 3: TesteGlider(mat); break;
	}
	
	int geracoes;
	printf("Digite o n�mero de gera��es:\n");
	scanf("%d",&geracoes);
	
	ImprimirMatriz(mat);
	for (int i = 1; i <= geracoes; i++)
	{	
		AplicarRegra(mat);
		ImprimirMatriz(mat);
	}	
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <locale.h> //Biblioteca para imprimir acentos corretamente

#define NCIDADES 5

void LerMatriz(int mat[NCIDADES][NCIDADES])
{
	for (int i = 0; i < NCIDADES; i++)
	{
		mat[i][i] = 0;
		for (int j = i+1; j < NCIDADES; j++)
		{
			printf("Informe a dist�ncia entre a cidade %d e %d:\n",i+1,j+1);
			scanf("%d",&mat[i][j]);
			mat[j][i] = mat[i][j]; //A volta tem a mesma dist�ncia da ida
		}
	}
}

void EncontrarRota(int cidadeInicial, int caminho[NCIDADES], int matD[NCIDADES][NCIDADES])
{
	int percorrida[NCIDADES];
	for (int i = 0; i < NCIDADES; i++)
		percorrida[i] = 0; //Por enquanto, ainda n�o passou por nenhuma cidade
	
	caminho[0] = cidadeInicial;
	percorrida[cidadeInicial] = 1; //J� passei pela cidade inicial!
	
	for (int i = 1; i < NCIDADES; i++)
	{
		//Estou na cidade cidadeAtual. Vou para onde?
		int cidadeAtual = caminho[i-1];
				
		int maisPerto = -1; //Ainda n�o sei qual �...
		for (int j = 0; j < NCIDADES; j++)			
		{
			if (percorrida[j] == 0) //Ainda n�o passei pela cidade j
			{
				if (maisPerto == -1)
					maisPerto = j; //A melhor op��o at� agora � a cidade j (a �nica at� agora)
				else				
					if (matD[cidadeAtual][j] < matD[cidadeAtual][maisPerto])								
						maisPerto = j;				
			}
		}
		
		//Vou para maisPerto agora!
		caminho[i] = maisPerto;
		percorrida[maisPerto] = 1; //J� passei pela cidade maisPerto!
	}
}

void ImprimirCaminho(int caminho[NCIDADES], int distancias[NCIDADES][NCIDADES])
{
	int distanciaAcumulada = 0;
	printf("A viagem come�a na cidade: %d\n",caminho[0]+1);
	for (int i = 1; i <= NCIDADES; i++)
	{
		int distProxima;
		if (i < NCIDADES)
			distProxima = distancias[caminho[i-1]][caminho[i]];
		else
			distProxima = distancias[caminho[i-1]][caminho[0]];
				
		if (distanciaAcumulada + distProxima > 1000 || ((distanciaAcumulada + distProxima) / 90) > 12)
		{
			printf("Parada obrigat�ria na cidade %d - Per�odo de Descanso\n",caminho[i-1] + 1);
			distanciaAcumulada = 0;
		}
		else
		{
			distanciaAcumulada = distanciaAcumulada + distProxima;
		}
		
		if (i < NCIDADES)
			printf("V� para a cidade %d.\n",caminho[i]+1);
		else
			printf("Retorne para a cidade de origem %d.\n",caminho[0]+1);		
	}
}

int main()
{
	setlocale(LC_ALL, "Portuguese");
	int distancias[NCIDADES][NCIDADES];
	LerMatriz(distancias);
	
	int cidadeInicial;
	printf("Digite a cidade inicial: \n");
	scanf("%d",&cidadeInicial);
	cidadeInicial = cidadeInicial - 1;
	
	int caminho[NCIDADES];
	EncontrarRota(cidadeInicial,caminho,distancias);
	
	ImprimirCaminho(caminho,distancias);
	
	return 0;
}

#include <stdio.h>

#define TAM 3

int Inicializar(int mat[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)
	{
		for (int j = 0; j < TAM; j++)
		{
			mat[i][j] = 0;
		}
	}
}

void ImprimirTabuleiro(int tab[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)
	{
		for (int j = 0; j < TAM; j++)
		{
			printf("%d ",tab[i][j]);
		}
		printf("\n");
	}
}

void Ler(int *l, int *c, int tab[TAM][TAM])
{
	int valida = 0;
	do
	{
		scanf("%d %d",l,c);
		if (*l < 1 || *l > TAM || *c < 1 || *c > TAM)
			valida = 0;
		else
			if (tab[*l-1][*c-1] != 0)
				valida = 0;
			else
				valida = 1;
		
		if (valida == 0)
			printf("Posi��o Inv�lida! Tente Novamente!\n");
	}
	while (valida == 0);
}

int AvaliarFimDeJogo(int tab[TAM][TAM], int jogador)
{
	int ct;
	
	for (int i = 0; i < TAM; i++)
	{
		ct = 0;
		//Se existir alguma linha i, onde todas as colunas j s�o marcadas pelo jogador 
		for (int j = 0; j < TAM; j++)
		{
			if (tab[i][j] == jogador)
			 	ct++;
		}
		if (ct == TAM) return 1;
	}
	
	for (int j = 0; j < TAM; j++)
	{
		ct = 0;
		//Se existir alguma coluna j, onde todas as linhas i s�o marcadas pelo jogador 
		for (int i = 0; i < TAM; i++)
		{
			if (tab[i][j] == jogador)
			 	ct++;
		}
		if (ct == TAM) return 1;
	}
	
	ct = 0;
	for (int i = 0; i < TAM; i++)
		if (tab[i][i] == jogador) 
			ct++;
	if (ct == TAM) return 1;
	
	ct = 0;
	for (int i = 0; i < TAM; i++)
		if (tab[i][TAM-1-i] == jogador) 
			ct++;
	if (ct == TAM) return 1;
	
	return 0;
}

int main()
{
	printf("Jogo da Velha!\n");
	
	int mat[TAM][TAM];
	Inicializar(mat);
	int j;
	for (j = 0; j < 9; j++)
	{
		int jogador = (j % 2) + 1; //se j % 2 == 0 ent�o jogador 1 sen�o jogador 2
		
		if (jogador == 1)
		{
			printf("Primeiro jogador:\n");
			int l,c;
			Ler(&l,&c,mat);
			mat[l-1][c-1] = 1;
		}
		else
		{
			printf("Segundo jogador:\n");
			int l,c;
			Ler(&l,&c,mat);
			mat[l-1][c-1] = 2;		
		}
		
		ImprimirTabuleiro(mat);
		
		int resultado = AvaliarFimDeJogo(mat, jogador);
		if (resultado != 0)
		{
			//Fim de Jogo!
			if (jogador == 1)			
				printf("Parab�ns! Primeiro jogador ganhou!\n");			
			else
				printf("Parab�ns! Segundo jogador ganhou!\n");
			break;
		}
	}
	
	if (j >= 9)
	{
		printf("Empate!\n");
	}
	
	return 0;
}

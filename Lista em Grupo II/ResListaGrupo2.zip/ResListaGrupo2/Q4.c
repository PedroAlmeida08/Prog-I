#include <stdio.h>
#include <stdlib.h>

#define TAM 23

void LerMatriz(char m[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)
		for (int j = 0; j < TAM; j++)
			scanf("%d",&m[i][j]);
}

void TesteElefante(char m[TAM][TAM])
{
	char aux[TAM][TAM] = 
	{
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{' ', ' ', ' ', '_', '_', '_', ' ', ' ', ' ', ' ', ' ', ' ', '_', '_', '_', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{' ', ' ', '/', ' ', ' ', ' ', '\\', '_', '_', '_', '_', '/', ' ', ' ', ' ', '\\', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{' ', '/', ' ', ' ', ' ', ' ', '/', ' ', '_', '_', ' ', '\\', ' ', ' ', ' ', ' ', '\\', ' ', ' ', ' ', ' ', ' ', ' ' },
		{'/', ' ', ' ', ' ', ' ', '|', ' ', ' ', '.', '.', ' ', ' ', '|', ' ', ' ', ' ', ' ', '\\', ' ', ' ', ' ', ' ', ' ' },
		{'\\', '_', '_', '_', '/', '|', ' ', ' ', ' ', ' ', ' ', ' ', '|', '\\', '_', '_', '_', '/', '\\', ' ', ' ', ' ', ' ' },
		{' ', ' ', ' ', '|', ' ', '|', '_', '|', ' ', ' ', '|', '_', '|', ' ', ' ', ' ', ' ', ' ', ' ', '\\', ' ', ' ', ' ' },
		{' ', ' ', ' ', '|', ' ', '|', '/', '|', '_', '_', '|', '\\', '|', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\\', ' ', ' ' },
		{' ', ' ', ' ', '|', ' ', ' ', ' ', '|', '_', '_', '|', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '|', '\\', ' ' },
		{' ', ' ', ' ', '|', ' ', ' ', ' ', '|', '_', '_', '|', ' ', ' ', ' ', '|', '_', '/', ' ', ' ', '/', ' ', ' ', '\\' },
		{' ', ' ', ' ', '|', ' ', '@', ' ', '|', ' ', ' ', '|', ' ', '@', ' ', '|', '|', ' ', '@', ' ', '|', ' ', ' ', '\'' },
		{' ', ' ', ' ', '|', ' ', ' ', ' ', '|', '~', '~', '|', ' ', ' ', ' ', '|', '|', ' ', ' ', ' ', '|', ' ', ' ', ' ' },
		{' ', ' ', ' ', '\'', 'o', 'o', 'o', '\'', ' ', ' ', '\'', 'o', 'o', 'o', '\'', '\'', 'o', 'o', 'o', '\'', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
		{ ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' }
	};
	
	for (int i = 0; i < TAM; i++)
		for (int j = 0; j < TAM; j++)
			m[i][j] = aux[i][j];
}

void LerArquivo(char m[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)
		for (int j = 0; j < TAM; j++)	
			m[i][j] = ' ';
	
	FILE *fp = fopen("testeArquivo.txt","r");
	
	char str[TAM+2];
    
    int i = 0;
	while (fgets(str, TAM+2, fp) != NULL)
	{
		for (int j = 0; j < TAM; j++)		
		{		
			m[i][j] = str[j];
			//printf("%c",m[i][j]);
		}
		//printf("\n");
		i++;
	}        
    fclose(fp);
}

void Imprimir(char mat[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)
	{
		for (int j = 0; j < TAM; j++)
			printf("%c",mat[i][j]);
		printf("\n");
	}
}

void Trocar(char *c1, char *c2)
{
	char aux = *c1;
	*c1 = *c2;
	*c2 = aux;
}

void EspelharH(char mat[TAM][TAM])
{
	for (int i = 0; i <= TAM / 2; i++)	
		for (int j = 0; j < TAM; j++)		
			Trocar(&mat[i][j],&mat[TAM-1-i][j]);
}

void EspelharV(char mat[TAM][TAM])
{
	for (int i = 0; i <= TAM / 2; i++)	
		for (int j = 0; j < TAM; j++)
			Trocar(&mat[j][i],&mat[j][TAM-1-i]);	
}

void RotacionarHorario(char mat[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)	
		for (int j = i+1; j < TAM; j++)
			Trocar(&mat[i][j],&mat[j][i]);
	EspelharV(mat);
}

void RotacionarAntiHorario(char mat[TAM][TAM])
{
	for (int i = 0; i < TAM; i++)	
		for (int j = i+1; j < TAM; j++)
			Trocar(&mat[i][j],&mat[j][i]);
	EspelharH(mat);
}


int main()
{
	char M[TAM][TAM];
	//LerMatriz(M);
	//TesteElefante(M);
	
	LerArquivo(M);
	Imprimir(M);
	system("pause");

	int R1, R2, EV, EH;
	
	Imprimir(M);
	RotacionarHorario(M);
	system("pause");
	
	Imprimir(M);
	RotacionarAntiHorario(M);
	system("pause");

	Imprimir(M);
	system("pause");
	/*
	
	printf("Efetuar quantas rota��es no sentido hor�rio?\n");
	scanf("%d",&R1);
	
	printf("Efetuar quantas rota��es no sentido anti-hor�rio?\n");
	scanf("%d",&R2);
	
	printf("Efetuar quantos espelhamentos verticais?\n");
	scanf("%d",&EV);
	
	printf("Efetuar quantos espelhamentos horizontais?\n");
	scanf("%d",&EH);
	
	for (int i = 1; i <= R1; i++)
		RotacionarHorario(M);
	
	for (int i = 1; i <= R2; i++)
		RotacionarAntiHorario(M);
		
	for (int i = 1; i <= EV; i++)
		EspelharV(M);
		
	for (int i = 1; i <= EH; i++)
		EspelharH(M);
	
	Imprimir(M);
	*/
	return 0;
}

#include <stdio.h>

#define TAM 10

void LerVetor(int *vet)
{
	for (int i = 0; i < TAM; i++)
		scanf("%d",&vet[i]);
}

void ImprimirVetor(int *vet, int tamVet)
{
	for (int i = 0; i < tamVet; i++)
		printf("%d ",vet[i]);
	printf("\n");
}

int ObterIntersecao(int *A, int *B, int *C)
{
	int tamC = 0;
	for (int i = 0; i < TAM; i++)
	{			
		for (int j = 0; j < TAM; j++)
		{
			if (A[i] == B[j])
			{
				//É necessário usar um contador adicional para inserir os elementos no vetor C. 
				C[tamC] = A[i];
				tamC = tamC + 1; 
			}
		}
	}
	return tamC;
}

int main()
{
	int A[TAM];
	int B[TAM];
	int C[TAM];
	
	LerVetor(A);
	LerVetor(B);
	
	imprimirVetor(A,TAM);
	imprimirVetor(B,TAM);
	
	int tamC = ObterIntersecao(A,B,C);
	
	ImprimirVetor(C,tamC);
	return 0;
}

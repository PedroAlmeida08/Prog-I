#include <stdio.h>

#define TAM_VET 100
#define TAM_MAT 10

void LerVetor(int *vet)
{
	for (int i = 0; i < TAM_VET; i++)
		scanf("%d",&vet[i]);
}

void ImprimirVetor(int *vet)
{
	for (int i = 0; i < TAM_VET; i++)
		printf("%d ",vet[i]);
}

void ImprimirMatriz(int mat[TAM_MAT][TAM_MAT])
{
	for (int i = 0; i < TAM_MAT; i++)
	{	
		for (int j = 0; j < TAM_MAT; j++)
			printf("%d ",mat[i][j]);
		printf("\n");
	}
}

void DobrarVetor(int *vet, int mat[TAM_MAT][TAM_MAT])
{
	int posVet = 0;
	for (int i = 0; i < TAM_MAT; i++)
	{
		if (i % 2 == 0)//As linhas pares seguem da esquerda para a direita
		{		
			for (int j = 0; j < TAM_MAT; j++)
			{			
				mat[i][j] = vet[posVet];
				posVet = posVet + 1;
			}
		}
		else
		{
			for (int j = TAM_MAT - 1; j >= 0; j--) //Já as ímpares, são adicionadas da direita para a esquerda.
			{			
				mat[i][j] = vet[posVet];
				posVet = posVet + 1;
			}
		}
	}
}


int main()
{
	int vet[TAM_VET];
	int mat[TAM_MAT][TAM_MAT];
	
	LerVetor(vet);
	
	DobrarVetor(vet,mat);
	
	ImprimirMatriz(mat);
	return 0;
}

#include <stdio.h>
#include <stdbool.h>

#define MAX 20

int Inserir(int valor, int *vet, int *posOcupadas)
{
	printf("Inserir: %d\n",valor);
	if (*posOcupadas < MAX)
	{
		int i = 0;
		//Encontrar onde o novo valor deve entrar:
		//Na primeira posi��o onde o valor no vetor for maior do que o valor que deve ser inserido
		while (i < *posOcupadas && vet[i] < valor) 
		{
			i = i + 1;					
		}	
		//se valor � o maior de todos (i = *posOcupadas) ou o vetor est� vazio -> inserir no final
		if (i > *posOcupadas)
		{
			vet[*posOcupadas] = valor;
			*posOcupadas = *posOcupadas + 1;
		}
		else
		{
			//i � o local do novo valor
			//Deslocar todos de i + 1 at� posOcupadas uma posi��o a frente
			for (int j = *posOcupadas; j > i; j--)
			{			
				vet[j] = vet[j-1];
			}
			vet[i] = valor;
			*posOcupadas = *posOcupadas + 1;
		}
		return true;
	}
	else
	{
		return false;
	}
}

bool Remover(int valor, int *vet, int *posOcupadas)
{
	printf("Remover: %d\n",valor);
	int i;
	for (i = 0; i < *posOcupadas; i++)
	{
		if (vet[i] == valor)
		{
			break; //achei o valor
		}
	}
	
	if (i >= *posOcupadas)
	{
		return false; //N�o localizado
	}
	else
	{
		//devo remover o elemento da posi��o i
		for (int j = i; j < *posOcupadas-1; j++)	
			vet[j] = vet[j + 1];
		*posOcupadas = *posOcupadas - 1;
		return true;
	}
}

void ImprimirVetor(int *vet, int posOcupadas)
{
	if (posOcupadas > 0)
	{
		printf("Vetor: ");
		for (int i = 0; i < posOcupadas; i++)
			printf("%d ",vet[i]);
		printf("\n");
	}
	else
	{
		printf("Vetor Vazio\n");
	}	
}

int main()
{
	int vet[MAX];
	int posOcupadas = 0;
	Inserir(1,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	Inserir(4,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	Inserir(2,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	Inserir(3,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	Inserir(5,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Remover(1,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Remover(5,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Remover(3,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Inserir(20,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Remover(4,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Inserir(10,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	Remover(20,vet,&posOcupadas);
	ImprimirVetor(vet,posOcupadas);
	
	return 0;	
}


#include <stdio.h>
#include <stdbool.h>

#define DIAS 30
#define JEJUM 0
#define POSPRANDIAL 1

bool Caso1(float medicoes[DIAS][2])
{
	int alterada = 0;
	for (int i = 0; i < DIAS; i++)
	{	
		//Caso as DUAS medi��es estejam alteradas
		if (medicoes[i][JEJUM] > 100 && medicoes[i][POSPRANDIAL] > 140)
			alterada = alterada + 1;
		else
			alterada = 0; //Reiniciar contagem
			
		if (alterada >= 5) 
			return true; //Encontrei 5 dias consecutivos onde os dois exames est�o alterados 
	}
	return false; //Como o return anterior n�o foi executado, ent�o as condi��es n�o foram atendidas	
}

bool Caso2(float medicoes[DIAS][2])
{
	int alterada = 0;
	for (int i = 0; i < DIAS; i++)
	{	
		//Caso uma das duas medi��es esteja alterada (ou as duas)
		if (medicoes[i][JEJUM] > 100 || medicoes[i][POSPRANDIAL] > 140)
			alterada = alterada + 1;
		else
			alterada = 0; //Reiniciar contagem
			
		if (alterada >= 10) 
			return true; //Encontrei 10 dias consecutivos onde um dos exames est� alterados 
	}
	return false; //Como o return anterior n�o foi executado, ent�o as condi��es n�o foram atendidas	
}

bool Caso3(float medicoes[DIAS][2])
{
	int alterada = 0;
	for (int i = 0; i < DIAS; i++)
	{	
		if (medicoes[i][JEJUM] > 100 || medicoes[i][POSPRANDIAL] > 140)
			alterada = alterada + 1;
			
		//Note que n�o h� o reset da contadora.	
		
		if (alterada >= 15) 
			return true; //Encontrei 15 dias onde um dos exames est� alterados 
	}
	return false; //Como o return anterior n�o foi executado, ent�o as condi��es n�o foram atendidas	
}

float CalcularMediaJejum(float medicoes[DIAS][2])
{
	float soma = 0;
	for (int i = 0; i < DIAS; i++)	
		soma = soma + medicoes[i][JEJUM];
	return soma / DIAS;
}

float CalcularMediaPosPrandial(float medicoes[DIAS][2])
{
	float soma = 0;
	for (int i = 0; i < DIAS; i++)	
		soma = soma + medicoes[i][POSPRANDIAL];
	return soma / DIAS;
}

void LerMedicoes(float medicoes[DIAS][2])
{
	for (int i = 0; i < DIAS; i++)
	{
		printf("Dia: %d\n",i+1);
		printf("Digite a glicemia de jejum:\n");
		scanf("%f",medicoes[i][JEJUM]);
		
		printf("Digite a glicemia p�s-prandial:\n");
		scanf("%f",medicoes[i][POSPRANDIAL]);
	}
}

int main()
{
	float medicoes[DIAS][2];
	LerMedicoes(medicoes);
	
	if (Caso1(medicoes) == true || Caso2(medicoes) == true || Caso3(medicoes) == true)
	{
		printf("Exames Alterados\n");
	}
	else
	{
		printf("Exames Normais\n");
	}
	printf("Jejum: %.1f\n",CalcularMediaJejum(medicoes));
	printf("P�s-prandial: %.1f\n",CalcularMediaPosPrandial(medicoes));
		
	return 0;
}
